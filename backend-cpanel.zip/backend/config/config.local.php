<?php

return [
    'JWT_SECRET' => '4624040f44e0c30a023ba3ac74e888202fa01edebebd54b3a674d2045a4272cb',
    'DB_HOST' => 'sql101.infinityfree.com',
    'DB_NAME' => 'if0_42784359_myscmanagement',
    'DB_USER' => 'if0_42784359',
    'DB_PASS' => '4naAUPQvgRj3',
];
