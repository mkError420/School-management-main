<?php

return [
    'JWT_SECRET' => '4624040f44e0c30a023ba3ac74e888202fa01edebebd54b3a674d2045a4272cb',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'jkivlrjg_mkschool',
    'DB_USER' => 'jkivlrjg_mkschool',
    'DB_PASS' => 'SftBrDgWFwBHRe9ZPapm',
];
